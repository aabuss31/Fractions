
package interestcalculator;

import java.util.Scanner;

public class InterestCalculator {
    
      private static double principal;
      private static double annualInterestRate;
      private static double monthlyInterestRate;
      private static double paymentPeriod;
      private static double n;
      private static double total;
      private static double top;
      private static double yearInterest;
      private static double end;
    
    
    public static void main(String[] args) {
        infoCollector();
        interestFormula();
        System.out.println("For a loan of " + principal + "at an annual interest rate of " + annualInterestRate
         + "compounded monthly for a period of " + paymentPeriod + ", the monthly payment is " + total);
        
        
        yearInterest = total*n;
        System.out.println("total amount paid is " + yearInterest);
        end = yearInterest - principal;
        System.out.println("of which " + end + "is interest");
        
    }
    
    public static void infoCollector(){
        Scanner a = new Scanner  (System.in);
        System.out.println("Welcome to the Interest/Monthly Payment calculator!");
        System.out.println("Enter Principal: ");
        principal = a.nextInt();
       
        System.out.println("Enter yearly interest rate (in %): ");
        Scanner b = new Scanner  (System.in);
        annualInterestRate = b.nextDouble();
        monthlyInterestRate = annualInterestRate/100/12;
        
        System.out.println("Enter number of years of the loan: ");
        Scanner c = new Scanner  (System.in);
        paymentPeriod = c.nextInt();
        n = paymentPeriod * 12;
        
        
    }//end method 
    
    public static void interestFormula(){
        top = (principal * monthlyInterestRate) ;
        total = top / (1 - (1/(Math.pow(1+monthlyInterestRate,n))));
        
    }
    
    
}
