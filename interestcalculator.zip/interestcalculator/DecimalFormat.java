
package interestcalculator;

/**
 *
 * @author aaron.buss
 */
public class DecimalFormat {
    
    
    public static void decimalFormat(){
         double total = 5785.901;
DecimalFormat form = new DecimalFormat(“0.00”);
    }



    
    
}
